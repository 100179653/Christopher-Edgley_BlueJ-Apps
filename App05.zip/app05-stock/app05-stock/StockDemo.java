import java.util.Random;
/**
 * Demonstrate the StockManager and Product classes.
 * The demonstration becomes properly onefunctional as
 * the StockManager class is completed.
 * 
 * @author Chris Edgley
 * @version 24.1.21
 */
public class StockDemo
{
    public static final int FIRST_ITEM_ID = 201;
    public static final int LAST_ITEM_ID = 210;
    
    // The stock manager.
    private StockManager manager;
    
    // This sets up a random amount of products for selling/deliveries
    private Random rnd;

    /**
     * Create a StockManager with 10 products.
     */
    public StockDemo(StockManager manager)
    {
        rnd = new Random(); 
        this.manager = manager;
        
        int id = FIRST_ITEM_ID; // 201
        manager.addProduct(new Product(id,"Samsung Galaxy S10 5G"));
        
        id++; // 202
        manager.addProduct(new Product(id,"Samsung Galaxy NOTE 20"));
        
        id++; // 203
        manager.addProduct(new Product(id,"Samsung Galaxy S20"));
        
        id++; // 204
        manager.addProduct(new Product(id,"Oppo Find X"));
        
        id++; // 205
        manager.addProduct(new Product(id,"Gogle Pixel 5"));
        
        id++; // 206
        manager.addProduct(new Product(id,"Xiaomi Mi 10 Lite"));
        
        id++; // 207
        manager.addProduct(new Product(id,"Poco F2 Pro"));
        
        id++; // 208
        manager.addProduct(new Product(id,"Poco M3"));
        
        id++; // 209
        manager.addProduct(new Product(id,"Apple iPhone 11 Pro Max"));
        
        id++; // 210
        manager.addProduct(new Product(id,"Apple iPhone SE"));
    }
    
    /**
     * Run all the methods necessary to show the program works, in sequence.
     */
    public void executeDemo()
    {
       System.out.println("-----------------------------------------");
       System.out.println("---   RUNNING STOCK DEMO SIMULATION   ---");
       System.out.println("-----------------------------------------");
       System.out.println();
        
       // Print all current products and stock
       System.out.println();
       System.out.println("--- PRINTING ALL PRODUCTS ---");
       System.out.println();
       manager.printAllProducts();
       
       // Deliver random qty of stock
       System.out.println();
       System.out.println("--- RECIEVING NEW STOCK ---");
       System.out.println();
       demoDeliverProducts();
       
       // Display all the stock after delivery
       manager.printAllProducts();
       
       // Sell random qty of products
       System.out.println();
       System.out.println("--- SELLING SOME PRODUCTS---");
       System.out.println();
       demoSellProducts();
       
       // Display all the stock after selling
       manager.printAllProducts();
       
       // Remove a product from the array
       System.out.println();
       System.out.println("--- REMOVING A PRODUCT ---");
       System.out.println();
       manager.removeProduct(209);
       
       // Correct mis-spelled stock item
       System.out.println();
       System.out.println("--- RENAMING A PRODUCT ---");
       System.out.println();
       manager.renameProduct(205, "Google Pixel 4a");
       
       // Search the product list by text matching 'Samsung'
       System.out.println();
       System.out.println("-- SEARCHING FOR A PRODUCT =-=");
       System.out.println();
       manager.searchProducts("Xiaomi");
       
       // Print all products with less than 2 in stock
       System.out.println();
       System.out.println("--- PRODUCTS WITH LESS THAN 3 IN STOCK ---");
       System.out.println();
       manager.printLowStockProducts(3);
    }
    
    /**
     * Show the StockManager can accept random delivery quantities
     */
    private void demoDeliverProducts()
    {
       for(int id = FIRST_ITEM_ID; id <= LAST_ITEM_ID; id++)
       {
           int quantity = rnd.nextInt(10) + 1; // random qty between 1 & 10 -- ensure at least 1
           manager.receiveStock(id, quantity);
       }
    }
   
    /**
     * Show that the StockManager can sell random quantities of all of the products
     * 
     */
    private void demoSellProducts()
    {
        // manager.printAllProducts();
        
        for(int identity = FIRST_ITEM_ID; identity <= LAST_ITEM_ID; identity++ )
        {
            int quantity = rnd.nextInt(6) + 1;
            manager.sellTheProduct(identity, quantity);
        }
        
        manager.printAllProducts();
    }
}
