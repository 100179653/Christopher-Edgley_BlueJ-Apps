/**
 * Model some details of a product sold by a company.
 * 
 * @author Chris Edgley
 * @version 24.01.21
 */
public class Product
{
    // An identifying number for this product.
    private int identifier;
    // The name of this product.
    private String name;
    // The quantity of this product in stock.
    private int quantity;

    /**
     * Constructor for objects of class Product.
     * The stock quantity at the beginning is zero.
     * @param identifier The product's identifying number.
     * @param name The product's name.
     */
    public Product(int identifier, String name)
    {
        this.identifier = identifier;
        this.name = name;
        quantity = 0;
    }

    /**
     * @return The product's id.
     */
    public int getIdentifier()
    {
        return identifier;
    }

    /**
     * @return The name of the product.
     */
    public String getThatName()
    {
        return name;
    }

    /**
     * @return The quantity that will be in stock.
     */
    public int getQty()
    {
        return quantity;
    }

    /**
     * @return The id of the stock, name of the stock and quantity in stock.
     */
    public String toString()
    {
        return identifier + ": " +  name + " Current stock level: " + quantity;
    }

    /**
     * Restock with the given amount of this product.
     * The current quantity is incremented by the given amount.
     * @param amount The number of new items added to the stock.
     *               This must be greater than zero.
     */
    public void incQuant(int amount)
    {
        if(amount > 0) 
        {
            quantity += amount;
        }
        else 
        {
            System.out.println("Error: Can't currently re-stock " + name + " with zero: " + amount);
        }
    }

    /**
     * This method allows the user to sell one of the items.
     * If there is no stock, An error is reported.
     */
    public boolean sellTheItem()
    {
        if(quantity > 0) 
        {
            quantity--;
            return true;
        }
        else 
        {
            System.out.println("ERROR: Current Item is out of stock: " + identifier + ":" + name);
            
            return false;
        }
    }
    
    /**
     * This method allows the user to be able to rename a product. In order
     * to reduce confusion, this should only be used in case of spelling mistakes
     */
    public void setName(String newName)
    {
        name = newName;
    }
}
