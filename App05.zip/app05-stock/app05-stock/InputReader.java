import java.util.Scanner;
/**
 * InputReader reads typed text input from the standard text terminal. 
 * The text typed by a user is returned.
 * 
 * @author Chris Edgley
 * @version 24.1.21
 */
public class InputReader
{
    private Scanner reader;

    /**
     * This class Create a new InputReader that reads 
     * text from the text terminal and allow the text 
     * to be used elsewhere in the program.
     * 
     */
    public InputReader()
    {
        reader = new Scanner(System.in);
    }

    /**
     * This will read a line of text from the text terminal
     * and return it as a String to the user.
     *
     * @return String using input by the user.
     */
    public String getString()
    {
        boolean isEntryCorrect = false; 
        
        System.out.print("> ");         
        String inputLine = reader.nextLine();
        if(inputLine.isBlank() || inputLine.isEmpty())
        {
            System.out.println("This input line is empty!");
        }
        
        return inputLine;
    }
    
}