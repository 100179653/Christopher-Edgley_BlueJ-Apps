/**
 * This app provides a user interface to the
 * stock manager so that users can add, edit,
 * print and remove stock products
 *
 * @author Chris Edgley
 * @version 09.01.21
 */
public class StockApp
{

    private InputReader reader;
    private StockManager manager;
    public final int ID_FIRST = 200; 
    private int nextID = ID_FIRST; 
    public final int MAX_SELL_AND_DELIVER = 50; 
    public static final char CLEAR_SCREEN = '\u000c';
    
    /**
     * Constructor for objects of class StockApp
     */
    public StockApp()
    {
        reader = new InputReader();
        manager = new StockManager();
        StockDemo demo = new StockDemo(manager);
        System.out.println(CLEAR_SCREEN);
    }

    /**
     *  This allows the program to tun at the beginning
     *  it prints my heading, then the menu the user uses
     *  for the program
     */
    public void run()
    {
        boolean finished = false;
        
        while(!finished)
        {
            printHeading();
            displayNumberedMenu();   
            String choice = reader.getString();
            runIntChoice(choice);
            if(choice.equals("9"))
            finished = true;
        }
    }
        
    /**
     * This is a switch statement with 9 commands to run
     * depending on the input of the user, it is outside
     * of the range 1-9 then it will stay blank
     */
    private boolean runIntChoice(String choice)
    {
        switch(choice)
        {
            case "1": addProduct(); break;
            case "2": removeProduct(); break;
            case "3": sellProduct(); break;
            case "4": deliverProduct(); break;
            case "5": restockProducts(); break;
            case "6": searchProducts(); break;
            case "7": printLowStock(); break;
            case "8": manager.printAllProducts(); break;
            case "9": return true;
            
            default: System.out.println("Please make a choice between 1-9");
        }
        return false;
    }
       
    /**
     * This will add a product to the ID table.
     * It will first check if it exists,
     * if not then it will add it to the ID
     * table.
     */
    public void addProduct()
    {
        System.out.println("Add new product");
        System.out.println();
        System.out.println("Please enter the ID of the new product");
        String identityNo = reader.getString();
        int identifier = Integer.parseInt(identityNo);
        
        Product product = manager.findProductByID(identifier);

        if(product.getIdentifier() == identifier)
        {
            System.out.println("This item already exists in the ID table");
        }
        else
        {
            System.out.println("Currently adding the new product");
            System.out.println("Please enter the name of the new product:");
            String name = reader.getString();
           
            Product newProduct = new Product(identifier, name);
            manager.addProduct(newProduct);
           
            System.out.println("\nYou have added the item: " + newProduct + "\n \nwith the ID of: " + identifier + "\n");
        }
    }
    
    /**
     * This will remove a product, if it exists, from the ID table
     */
    private void removeProduct()
    {
        System.out.println(" Remove a product");
        System.out.println();      
        
        System.out.println("Please enter the ID of the product to remove");
        String idNumber = reader.getString();
        int id = Integer.parseInt(idNumber); 
        
        Product product = manager.findProductByID(id);
        if(product.getIdentifier() == id)
        {
             System.out.println("This produce has been removed");
             manager.removeProduct(id);
        }
        else 
        {
             System.out.println("I can not find this item! maybe it doesn't exist currently");
        }
                
    }
    
    /**
     * This will sell a product by checking if the item
     * exists and is in stock, if not then it either
     * tells you the item doesn't exist or the item
     * can not be sold due to a lack of stock
     */
    private void sellProduct()
    {
        System.out.println(" Sell products");
        System.out.println();
        
        System.out.println("Please enter the ID of the product to sell");
        String idNumber = reader.getString();
        int identifier = Integer.parseInt(idNumber);
        
        Product product = manager.findProductByID(identifier);
        
        if(product.getIdentifier() == identifier)
        {
             System.out.println("Please enter the qty of the product to sell");
             String sellQty = reader.getString();
             int qty = Integer.parseInt(sellQty);
        
             if (qty >= 1 && qty < MAX_SELL_AND_DELIVER)
             {
                 manager.sellTheProduct(identifier, qty);
             }
             else
             {
                 System.out.println("Sorry you cannot sell that amount\n");
             }
                  
        }
        else 
        {
             System.out.println("Item does not exist");
        }
        
    }
    
    /**
     * This will deliver a product. it does this 
     * by checking if the quantity needed is in
     * stock. If it is, then it shall be delivered
     * or if not then it shows that you can't
     */
    private void deliverProduct()
    {
        System.out.println(" Deliver products");
        System.out.println();
        
        System.out.println("Please enter the ID of the product to deliver");
        String identityNo = reader.getString();
        int identity = Integer.parseInt(identityNo);
        
        Product product = manager.findProductByID(identity);
        
        if(product.getIdentifier() == identity)
        {
             System.out.println("Please enter the quantity of the product to deliver");
             String receiveQty = reader.getString();
             int qty = Integer.parseInt(receiveQty);
        
             if (qty >= 1 && qty < MAX_SELL_AND_DELIVER)
             {
                 manager.receiveStock(identity, qty);
             }
             else
             {
                 System.out.println("Sorry you cannot deliver that amount\n");
             }
                  
        }
        else 
        {
             System.out.println("Item does not exist");
        }
    }
    
    /**
     * This will try to restock products with the number
     * the user chooses
     */
    private void restockProducts()
    {
        System.out.println(" Restock Items");
        System.out.println();
        
        String prompt = ("Please enter a minumum to reload the stock: ");
        String stockQty = reader.getString();
        int qty = Integer.parseInt(stockQty);
        
        manager.restockLowProducts(qty);
    }
    
    /**
     * This will print all items which are 
     * currently low in stock 
     */
    private void printLowStock()
    {
        System.out.println(" Printing low stock");
        System.out.println();
        
        manager.printLowStockProducts(1);        
    }
    
    /**
     * This will open an input for the user to enter then searches for 
     * products that includes what you typed
     */
    private void searchProducts()
    {
        System.out.println("Search Products");
        System.out.println();
        System.out.println("Please enter the name of the product you want to search: ");
        String searching = reader.getString();
        
        System.out.println("now displaying current products matching " + searching + "\n");
        manager.searchProducts(searching);

    }
    
    /**
     * This will display a menu that you can select which number from to run the command 
     */
    private void displayNumberedMenu()
    {
        System.out.println();
        System.out.println("1.   Add a new product");
        System.out.println("2.   Remove a product");
        System.out.println("3.   Sell your Products");
        System.out.println("4.   Deliver your Products");
        System.out.println("5.   Restock your Products");
        System.out.println("6.   Search for Products");
        System.out.println("7.   Display items low in stock");
        System.out.println("8.   Show all your current Products");
        System.out.println("9.   Quit the application");
        System.out.println();
    }
    
    /**
     * Print the title of the program and the authors name
     */
    private void printHeading()
    {
        System.out.println("-------------------------------");
        System.out.println("-    Stock Management App     -");
        System.out.println("-      By Chris Edgley        -");
        System.out.println("-------------------------------");
    }
}
