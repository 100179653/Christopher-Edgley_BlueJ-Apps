import java.io.IOException;
import java.lang.InterruptedException;

/**
 * This class creates a stockapp for the
 * user to
 *
 * @author Chris Edgley
 * @version 24.1.21
 */
public class Program
{
    private static StockApp app;

    /**
     * This class creates and runs an instance of
     * the StockApp class
     */
    public static void main() throws IOException, InterruptedException
    {
        app = new StockApp();
        app.run();
    }
}
