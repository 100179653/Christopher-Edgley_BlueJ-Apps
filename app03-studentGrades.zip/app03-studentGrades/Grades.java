
/**
 * Enumeration class Grades - write a description of the enum class here
 *
 * @author Chris Edgley
 * @version 24.10.2020
 */
public enum Grades
{
    X, F, D, C, B, A
}
