
/**
 * This class stores information about a course
 * that enrolled students may want to complete
 *
 * @author Chris Edgley
 * @version 2020.10.24
 */
public class Course
{
     // instance variables - These variables are global so that I can use them 
     // within the Course Class
     public static final int maxModules = 4;
    
     private String codeNo;
     private String title;
    
     private Module module1;
     private Module module2;
     private Module module3;
     private Module module4;
    
     private int numModules;
     private int finalCredits;
     private int meanMark;
     private int finalMark;   
    
     private boolean complete;
    
     /**
      *    This establishes a method where we can create a Course using a 
      *    string for the title and code number.
      */
     public Course(String title, String codeNo)
     {
        // initialise instance variables
        this.codeNo = codeNo;
        this.title = title;
        
        numModules = 0;
        finalMark = 0;
        finalCredits = 0;
        complete = false;
     }
    
     /**
      * This method allows the implementation of a mark to be awarded to a 
      * module
      */
      public void awardMark (int mark, int moduleNo)
     {
       if(moduleNo == 1)
       {
           module1.awardMark(mark);
       }
       if (moduleNo == 2)
       {
           module2.awardMark(mark);
       }
       if (moduleNo == 3)
       {
           module3.awardMark(mark);
       }
       if (moduleNo == 4)
       {
           module4.awardMark(mark);
       }
       else
       {
          System.out.println("this is an incorrect mark");
       }
     }    
  
     /**
      * Add module 1 to 4 to the Course
      */
     public void addModule(int number, Module module)
     {
        if((number >= 1) && (number <= maxModules)) numModules++;
        
        switch(number)
        {
            case 1: module1 = module; break;
            case 2: module2 = module; break;
            case 3: module3 = module; break;
            case 4: module4 = module; break;
        }
     }
    
     /**
      * Prints out the details of a course
      */
     public void print()
     {
        // put your code here
        System.out.println("Course " + codeNo + " - " + title);
        System.out.println();
        
        printModules();
       
     }
    
     /**
      * Prints all the modules if inputted by the user
      */
     private void printModules()
     {
        if(module1 != null) module1.print();
        if(module2 != null) module2.print();
        if(module3 != null) module3.print();
        if(module4 != null) module4.print();
     }
    
     /**
      *  prints out the user's final mark and grade 
      */ 
     public void printGrade()
     {
       if(numModules == maxModules)
       {
           finalMark = 0;
           
           addMark(module1);
           addMark(module2);
           addMark(module3);
           addMark(module4);
           
           if(finalCredits == maxModules *  Module.CREDIT)
           {
               System.out.println("Your final mark is " + finalMark / maxModules + 
                                  " your final grade is " + calculateGrade());
             
               
           }
           else
           {
               System.out.println("You have not completed the course yet!");
            }
       }
     }
   
     /**
      * used to calculate a person's grade
      */
     private String calculateGrade()
     {
       meanMark = finalMark / maxModules;
       
       if(meanMark < 40)
       {
           return "F";
       }
       else if(meanMark < 50)
       {
           return "D";
       }
       else if(meanMark < 60)
       {
           return "C";
       }
       else if(meanMark < 70)
       {
           return "B";
       }
       else if(meanMark < 100)
       {
           return "A";
       }
       else
       {
           return "X";
       }    
     }

     /**
      * this adds a mark to a module
      */
     private void addMark(Module module)
     {
       if(module.isComplete())
       {
           finalMark = finalMark + module.getMark();
           finalCredits += module.CREDIT;
       }
     }
   
  
}
