
/**
 * The Module Class was created so that we can enter information about different parts of a course and enable students to be 
 * marked based upon an average for their modules
 *
 * @author Chris Edgley
 * @version 24.10.2020
 */
public class Module
{
    // instance variables - These variables are global so that I can use them 
    // within the Module Class
    public static final int CREDIT = 25;
   
    private String title;
    private String codeNo;
   
    private int mark;
    private boolean complete;
   
    /**
     * This allows us to create a module object
     */
    public Module(String title, String codeNo)
    {
        mark = -1;
        complete = false;
        
        this.title = title;
        this.codeNo = codeNo;
    }
    
    /**
     * gets the mark for the module
     */
     public int getMark()
    {
        return mark;
    }
    
    /**
     * A mark has been awarded and the module is
     * completed
     */
     public boolean isComplete()
    {
        return complete;
    }
    
    /**
     * This allows us to create and award a mark to said module
     */
    public void awardMark(int mark)
    {
        if ((mark >= 0) && (mark <=100))
        {
            this.mark = mark;
            complete = true;
        }
        else
        {
           System.out.println("Please enter a valid mark");
        }
    }
    
    /**
     * This will print information about the module
     */
    public void print()
    {
        System.out.println("Module: " + codeNo + " " + title);
        
        if(isComplete())
        {
            System.out.println(" Mark = "+ mark);
        }
        else
        {
            System.out.println(" is not completed yet!");
        }
    }
    
}
