/**
 * Model some details of a product sold by a company.
 * 
 * @author Christopher Edgley.
 * @version 2020.11.11
 */
public class Item
{
    // An identifying number for this product.
    private int identifier;
    // The name of this product.
    private String productName;
    // The quantity of this product in stock.
    private int quantity;

    /**
     * Constructor for objects of class Product.
     * The initial stock quantity is zero.
     * @param id The product's identifying number.
     * @param name The product's name.
     */
    public Item(int identifier, String name)
    {
        this.identifier = identifier;
        this.productName = name;
        quantity = 0;
    }
    
    /**
     * Restock with the given amount of this product.
     * The current quantity is incremented by the given amount.
     * The number of new items added to the stock.
     * This must be greater than zero.
     */
    public void increaseQuantity(int amount)
    {
        if(amount > quantity) 
        {
            quantity += amount;
        }
        else 
        {
            System.out.println("Attempting to restock " + productName +
                               " with this many: " + quantity);
        }
    }
    
    /**
     * @return The product's id.
     */
    public int getID()
    {
        return identifier;
    }

    /**
     * @return The product's name.
     */
    public String getName()
    {
        return productName;
    }

    /**
     * @return The quantity in stock.
     */
    public int getQuantity()
    {
        return quantity;
    }

    /**
     * @return The id, name and quantity in stock.
     */
    public String toString()
    {
        return identifier + ": " +  productName + " stock level: " + quantity;
    }
    
    /**
     * The products name should only be changed if there is
     * a spelling mistake, otherwise it will cause confusion
     */
    public void setName(String newName)
    {
        productName = newName;
    }

    /**
     * Sell one of these products.
     * An error is reported if there appears to be no stock.
     */
    public boolean sellingOne()
    {
        if(quantity > 0) 
        {
            quantity--;
            return true;
        }
        else 
        {
            System.out.println(
                "Attempt to sell an out of stock item: " + identifier + 
                ":" + productName);
            
                return false;
        }
    }

}
