import java.util.Random;

/**
 * This class will be used to demonstrate what the StockManager
 * and the Item class actually does by running a demo
 * 
 * @author Christopher Edgley.
 * @version 2020.11.11
 **/
 
public class StockDemo
{
    public static final int INITIAL_ID = 900;
    public static final int FINAL_ID = 909;
    
    // The stock stockManager.
    private StockManager stockManager;
    
    private Random ranGen;

    /**
     * This method creates a stock stockManager with 10 sample Items
     * 
     */
    public StockDemo(StockManager stockManager)
    {
        ranGen = new Random();
        this.stockManager = stockManager;
        
        int identifier = INITIAL_ID;
        stockManager.addItem(new Item(identifier,"Apple iPhone 11"));
        
        identifier++;
        stockManager.addItem(new Item(identifier,"Samsung Galaxy S21"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Xiaomi Poco X3"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Huawei P30 Lite"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Google Pixel 5 5G"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Apple iPhone SE"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Huawei Mate 30 Pro"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Huawei Mate Xs 5G"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Sony Xperia 5"));
        
        identifier++; 
        stockManager.addItem(new Item(identifier,"Xiamoi Mi 10 Pro"));
    }
       
      /**
     * Demonstrate that the StockManager can sell all
     * different quantities of all of the Items
     */
    private void demoSellItems()
    {
        stockManager.printAllItems();
        
        for(int id = INITIAL_ID; id < FINAL_ID; id++ )
        {
            int quantity = ranGen.nextInt(6) + 1;
            stockManager.sellItem(id, quantity);
            
        }
     
        stockManager.printAllItems();
    }
    
    /**
     * this method runs a demo where it similates deliveries from suppliers 
     */
    private void demoDeliverItems()
    {
       for(int identifier = INITIAL_ID; identifier < FINAL_ID; identifier++)
       {
           int quantity = ranGen.nextInt(8) + 1;
           stockManager.doDelivery(identifier, quantity);
       }
    }
    
    /**
     * this method runs a demo based upon all the criteria for App04
     */
    public void runDemo()
    {
       stockManager.printAllItems();
       demoDeliverItems();
       stockManager.printAllItems();
       demoSellItems();
       stockManager.printAllItems();
       
       stockManager.removeItem(102);
       
       stockManager.renameItem(109, "Xiaomi Mi 10 Pro");
       stockManager.restockLowItems(3);
       stockManager.searchItems("Xiaomi");
       stockManager.printAllItems();
    }

}
