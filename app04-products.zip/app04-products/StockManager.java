import java.util.ArrayList;

/**
 * Manage the stock in a business.
 * The stock is described by zero or more items.
 * 
 * @author Christopher Edgley.
 * @version 2020.11.11
 */
public class StockManager
{
    // A list of the items.
    private ArrayList<Item> stock;

    /**
     * Initialise the stock manager.
     */
    public StockManager()
    {
        stock = new ArrayList<>();
    }

    /**
     * Add a item to the list.
     * @param item The item to be added.
     */
    public void addItem(Item item)
    {
        stock.add(item);
    }
    
    /**
     * Receive a delivery of a particular item.
     * Increase the quantity of the item by the given amount.
     * @param id The ID of the item.
     * @param amount The amount to increase the quantity by.
     */
    public void doDelivery(int identifier, int amountDelivery)
    {
        Item item = findItem(identifier);
        
        if(item == null)
        {
            System.out.println("\n item ID" + identifier + " not found! \n"); 
        }
        else
        {
            System.out.println("\n" + item);
            item.increaseQuantity(amountDelivery);
            System.out.println("    ** Re-Stocked by " + amountDelivery + " ***");
            System.out.println(item + "\n");
        }
    }
    
    /**
     * Sell the given item with matching id quantity
     * times providing there are suficient numbers in stock.
     * Otherwise sell as many as possible.
     * @param id The ID of the item being sold.
     */
    public void sellItem(int identifier, int quantitySell)
    {
        Item item = findItem(identifier);
        
        if(item != null) 
        {
            System.out.println("Selling item: Order Quantity = " + quantitySell);
            printItem(identifier);

            int noSold = quantitySell;
            if(noSold > item.getQuantity())
            {
                noSold = item.getQuantity();
            }
            
            for(int count = 0; count < noSold; count++)
            {
                item.sellingOne();
            }
            
            System.out.println("  " + noSold + " items sold!\n");
        }
    }
    
    /**
    *  Print all items with zero quantity in the system
    */
    public ArrayList<Item> printLowStockItems(int minimum)
    {
        ArrayList<Item> lowStock = new ArrayList<Item>();
        int count = 0;
        
        System.out.println(" Printing all low stock items");
        System.out.println();
        
        for(Item item : stock)
        {
            if(item.getQuantity() <= minimum)
            {
                count++;
                lowStock.add(item);
                System.out.println(item);
            }
        }
        
        System.out.println();
        System.out.println("There were " + count + 
                           " stock items with less than " + minimum +
                           " items\n");
        return lowStock;
    }
    
    /**
     * This method allows a user to search for a phrase
     * i.e. a phone Manufacturer's name and search all 
     * the items in the system for them
     */
    public void searchItems(String targetPhrase)
    {
        int count = 0;
        System.out.println("\nSearching for " + targetPhrase + "\n");
        
        for(Item item : stock)
        {
            if(item.getName().contains(targetPhrase))
            {
                System.out.println(item);
                count++;
            }
        }
        
        System.out.println("\nThere are " + count + " items containing " + 
                            targetPhrase + " in their name!\n");
    }
    
        /**
     * Print details of all the items.
     */
    public void printAllItems()
    {
       System.out.println("\n*******************************");
       System.out.println("  Phone Management System");
       System.out.println("     by Christopher Edgley ");
       System.out.println("*******************************\n");
       
        for(Item item : stock)
        {
            System.out.println(item);
        }
        
        System.out.println();
    }
    
    /**
     * Increase the quantity of stock for all items in the lowStock
     * ArrayList.
     */
    public void restockLowItems(int minimum)
    {
       ArrayList<Item> lowStock = printLowStockItems(minimum);
       
       System.out.println("\nRe-Stocking to a minimum level of " + 
                          minimum + "\n");
                          
       for(Item item : lowStock)
       {
          item.increaseQuantity(minimum - item.getQuantity()); 
       }
    }
    
    /**
     * If the item exists that matches the id
     * remove that item from the list.
     */
    public void removeItem(int identifier)
    {
        Item item = findItem(identifier);
        
        if(item == null)
        {
            System.out.println("\n item ID " + identifier + " HAS NOT BEEN FOUND! Please try again!\n");
        }
        else
        {
            stock.remove(item);
            System.out.println("\n item ID " + identifier + " REMOVED! \n");            
        }
    }
    
    /**
     * This allows the user to rename an item in the system
     * if, for example, there was a spelling mistake on the name
     */
    public void renameItem(int identifier, String newName)
    {
        Item item = findItem(identifier);
        
        if(item == null)
        {
            System.out.println(" item id = " + identifier + " not found!");
        }
        else
        {
            System.out.println(item);
            item.setName(newName);
            System.out.println("***RENAMED***");
            System.out.println(item);
        }
    }
    
    /**
     * Show details of the given item. If found,
     * its name and stock quantity will be shown.
     * @param id The ID of the item to look for.
     */
    public void printItem(int id)
    {
        Item item = findItem(id);
        
        if(item != null) 
        {
            System.out.println(item);
        }
        else
        {
            System.out.println("Item not found, please try again!");
        }    
    }    
    
    /**
     * Try to find a item in the stock with the given id.
     * @return The identified item, or null if there is none
     *         with a matching ID.
     */
    public Item findItem(int identifier)
    {
        int index = 0;
        boolean found = false;
        Item item = null;
        
        while(!found && index < stock.size())
        {
           item = stock.get(index);
           if(item.getID() == identifier)
           {
               found = true;
           }
           else index++;
        }
        
        return item;
    }
    
}
