
/**
 * Write a description of class Course here.
 *
 * @author Chris Edgley
 * @version 2.10.20
 */
public class Course
{
   
    //This will set the name of the course 
    private String courseName;
    //This will set up the course number field
    private String courseID;
    /**
     * Constructor for objects of class Course
     */
    public Course(String courseName, String courseID)
    // This will call to provide the course name and ID from you
    {
      this.courseName = courseName;
      this.courseID = courseID;
    }
    
    public void print ()
    {
        System.out.println("Course," + courseName + " ID " + courseID);
    }
}
