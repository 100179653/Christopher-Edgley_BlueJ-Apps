
/**
 * The course class represents what the student can be on as a whole
 * course can be attached to many lab classes
 *
 * @author Chris Edgley
 * @version 20.09.29
 */
public class Course
{
   
    //This will set the name of the course 
    private String courseName;
    //This will set up the course number field
    private String courseID;
   
    public Course(String courseName, String courseID)
    // This will call to provide the course name and ID from you
    {
      this.courseName = courseName;
      this.courseID = courseID;
    }
    
    public void print ()
    {
        System.out.println("Course," + courseName + " ID " + courseID);
    }
}
