import java.io.*;
import java.text.SimpleDateFormat;

/**
 * TicketMachine models a ticket machine that issues
 * flat-fare tickets.
 * The price of a ticket is specified via the constructor.
 * Instances will check to ensure that a user only enters
 * sensible amounts of money, and will only print a ticket
 * if enough money has been input.
 * 
 * @author Chris Edgley
 * @version 2020.10.18
 */
public class TicketMachine

{
    // The price of a fixed ticket from this machine
    public static final Ticket AYLESBURY_TICKET = new Ticket("Aylesbury", 220);
    public static final Ticket AMERSHAM_TICKET = new Ticket("Amersham", 300);
    public static final Ticket HIGH_WYCOMBE_TICKET = new Ticket("High Wycombe", 330);
    
    private Ticket ticketCurrent;
    
    // The price of a ticket from this machine.
    private int price;
    // The amount of money entered by a customer so far.
    private int balance;
    // The total amount of money collected by this machine.
    private int total;
    // The total amount of money youhave in the system
    private int Money;
    //The formatter is to see how your date is seen on the ticket
    private SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    
    /**
     * Create a machine that issues tickets of the given price.
     */
    public TicketMachine()
    {
        ticketCurrent=null;
        balance = 0;
        total = 0;
    }
    
    /**
     * This will print all the destinations and their price
     */
    
    public void printAllDestinations()
    {
        System.out.print(" Tickets to "+ AYLESBURY_TICKET.findDestination ());
        System.out.print(" are "+ AYLESBURY_TICKET.findPrice());
        System.out.print(" pence.");
        System.out.println(" ");
        System.out.print(" Tickets to "+ AMERSHAM_TICKET.findDestination());
        System.out.print(" are "+ AMERSHAM_TICKET.findPrice());
        System.out.println(" pence.");
        System.out.print(" ");
        System.out.print("Tickets to "+ HIGH_WYCOMBE_TICKET.findDestination());
        System.out.print(" are "+ HIGH_WYCOMBE_TICKET.findPrice());
        System.out.println(" pence.");
        System.out.print(" ");
    }    
    
    /**
     * This adds the ticket for the Aylesbury train.
     */
    public void addAylesbury()
    {
        ticketCurrent = AYLESBURY_TICKET;
        price = 220;
        System.out.println("You have selected the Aylesbury Ticket");
        System.out.println("A cost of £2.20");
    }
    
    /**
     * This adds the ticket for the Amersham train.
     */
    public void addAmersham()
    {
        ticketCurrent = AMERSHAM_TICKET;
        price = 300;
        System.out.println("You have selected the Amersham Ticket");
        System.out.println("A cost of £3.00");
    }
    
    /**
     * This adds the ticket for the High Wycombe train.
     */
    public void addWycombe()
    {
        ticketCurrent = HIGH_WYCOMBE_TICKET;
        price = 330;
        System.out.println("You have selected the High Wycombe Ticket."); 
        System.out.println("A cost of £3.30");
    }
    
    /**
     * This allows the system to update your current balance and display 
     * your updated balance
     */
    public void balanceUpdater (int Coin)
    {
       balance = balance + Coin;
    }
    
    /**
     * This is a function that calls upon what your current balance is 
     * and shows it to you
     */
    public void displayBalance()
    {
       System.out.println ("Current Balance: " + balance);
    }
    
    /**
     * This allows only 10p, 20p, £1.00 and £2.00 coins to be entered into the system
     */
    public void insertCoins (int value)
    {
      switch(value)
      {
          case 10:
            balanceUpdater(value);
            System.out.println ("You have inserted 10 pence.");
            System.out.println ("your new balance is " + balance);
            break;
          case 20: 
            balanceUpdater(value);
            System.out.println ("You have inserted 20 pence.");
            System.out.println ("your new balance is " + balance + " pence.");
            break;
          case 100: 
            balanceUpdater(value);
            System.out.println ("You have inserted 1 pound.");
            System.out.println ("your new balance is " + balance + " pence.");
            break;
          case 200: 
            balanceUpdater(value);
            System.out.println ("You have inserted 2 pounds.");
            System.out.println ("your new balance is " + balance + " pence.");
            break;
          
          default:
            System.out.println(value + " This is not a valid coin");
      }
    }    
    
    /**
     * @Return The price of a ticket.
     */
    public int getPrice()
    {
     return price;
    }
  
    /**
     * Print a ticket if enough money has been inserted, and
     * reduce the current balance by the ticket price. Print
     * an error message if more money is required.
     */
    public void printTicket()
    {
        String date = formatter.format(ticketCurrent.findCurrentDate());
        String destination = ticketCurrent.findDestination();
        
        if(balance >= price) {
            // Simulate the printing of a ticket.
            System.out.println("##################");
            System.out.println("Your ticket to");
            System.out.println(destination);
            System.out.println("On Date: " + date);
            System.out.println("Cost: " + price + " pence.");
            System.out.println("##################");
            System.out.println();

            // Update the total collected with the price.
            total = total + price;
            // Reduce the balance by the prince.
            balance = balance - price;
        }
        else {
            System.out.println("You must insert at least: " +
                               (price - balance) + " more pence.");
                    
        }
    }

    /**
     * Return the money in the balance.
     * The balance is cleared.
     */
    public int refundBalance()
    {
        int amountToRefund;
        amountToRefund = balance;
        balance = 0;
        return amountToRefund;
    }
}
