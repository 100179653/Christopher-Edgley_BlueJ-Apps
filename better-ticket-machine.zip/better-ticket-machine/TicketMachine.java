
/**
 * TicketMachine models a ticket machine that issues
 * flat-fare tickets.
 * The price of a ticket is specified via the constructor.
 * Instances will check to ensure that a user only enters
 * sensible amounts of money, and will only print a ticket
 * if enough money has been input.
 * 
 * @author Chris Edgley
 * @version 2020.10.18
 */
public class TicketMachine

{
    // The price of a fixed ticket from this machine
    public static final Ticket AYLESBURY_TICKET = new Ticket("Aylesbury", 220);
    public static final Ticket AMERSHAM_TICKET = new Ticket("Amersham", 300);
    public static final Ticket HIGH_WYCOMBE_TICKET = new Ticket("High Wycombe", 330);
    
    private Ticket ticketCurrent;
    
    // The price of a ticket from this machine.
    private int price;
    // The amount of money entered by a customer so far.
    private int balance;
    // The total amount of money collected by this machine.
    private int total;
    // The total amount of money youhave in the system
    private int Money;
    
    /**
     * Create a machine that issues tickets of the given price.
     */
    public TicketMachine()
    {
        ticketCurrent=null;
        balance = 0;
        total = 0;
    }
    /**
     * This adds the ticket for the Aylesbury event.
     */
    public void addAylesbury()
    {
        ticketCurrent = AYLESBURY_TICKET;
        price = 220;
    }
    /**
     * This adds the ticket for the Amersham event.
     */
    public void addAmersham()
    {
        ticketCurrent = AMERSHAM_TICKET;
        price = 300;
    }
    /**
     * This adds the ticket for the High Wycombe event.
     */
    public void addWycombe()
    {
        ticketCurrent = HIGH_WYCOMBE_TICKET;
        price = 330;
    }
    /**
     * This allows the system to update your current balance and display your updated balance
     */
    public void balanceUpdater (int Coin)
    {
       balance = balance +Coin;
    }
    /**
     * This is a function that calls upon what your current balance is and shows it to you
     */
    public void displayBalance()
    {
       System.out.println ("Current Balance: " + balance);
    }
    public void insertCoins (Coin Coin)
    {
        balanceUpdater(Coin.getValue());
    }
    /**
     * This allows only 10p, 20p, £1.00 and £2.00 coins to be entered into the system
     */
    public void insertCoins (int value)
    {
      switch(value)
      {
          case 10:
            balanceUpdater(value);
            break;
          case 20: 
            balanceUpdater(value);
            break;
          case 100: 
            balanceUpdater(value);
            break;
          case 200: 
            balanceUpdater(value);
            break;
          
          default:
            System.out.println(value + " This is not a valid coin");
      }
    }    
    /**
     * @Return The price of a ticket.
     */
    public int getPrice()
    {
     return price;
    }
    /**
     * Return The amount of money already inserted for the
     * next ticket.
     */
    public int getBalance()
    {
        return balance;
    }
    /**
     * Print a ticket if enough money has been inserted, and
     * reduce the current balance by the ticket price. Print
     * an error message if more money is required.
     */
    public void printTicket()
    {
        if(balance >= price) {
            // Simulate the printing of a ticket.
            System.out.println("##################");
            System.out.println("# Your New" );
            System.out.println("# Ticket");
            System.out.println("# " + price + " pence.");
            System.out.println("##################");
            System.out.println();

            // Update the total collected with the price.
            total = total + price;
            // Reduce the balance by the prince.
            balance = balance - price;
        }
        else {
            System.out.println("You must insert at least: " +
                               (price - balance) + " more pence.");
                    
        }
    }

    /**
     * Return the money in the balance.
     * The balance is cleared.
     */
    public int refundBalance()
    {
        int amountToRefund;
        amountToRefund = balance;
        balance = 0;
        return amountToRefund;
    }
}
