import java.util.Date;
/**
 *  This is the class for a Ticket 
 *
 * @Chris Edgley (your name)
 * @2020.10.18 (a version number or a date)
 */
public class Ticket
{
    // instance variables - replace the example below with your own
    private int price;
    private String destination;
    private Date currentDate = new Date();

    /**
     * Constructor for objects of class Ticket
     */
    public Ticket(String destination, int price)
    {
        //This establishes the destination and price of a ticket
       this.destination = destination;
       this.price = price;
    }

    /**
     * This will call for the class of Price to find it
     */
    public int findPrice()
    {
        // this will return the price to the customer
        return price;
    }
    public String findDestination()
    /**
     * This will call for the class of Destination to find it
     */
    {
        // 
        return destination;
    }
    public Date findCurrentDdate()
    /**
     * This will show to the user what the current date
     */
    {
        return currentDate;
    }
}
